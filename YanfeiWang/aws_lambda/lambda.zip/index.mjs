import axios from "axios";
// export const handler = async(event) => {
//     const url = "https://r76hxxlfrylohj4hmygbeqqhdy0fhgrx.lambda-url.us-west-2.on.aws/";
//     const res = await axios.post('url');
//     const r = {
//             statusCode: 200,
//             body: JSON.stringify(res),
//         };
//     return r;
    
// };

import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  ScanCommand,
  PutCommand,
  GetCommand,
  DeleteCommand,
} from "@aws-sdk/lib-dynamodb";

// const tableName = "iot_simulate_data_new";
const tableName = "iot_simulate"

const client = new DynamoDBClient({});

const dynamo = DynamoDBDocumentClient.from(client);

// const tableName = "iot_simulate_data_new";

export const handler = async(event) => {
    const ts1 = event['ts1']; // 1545436697.27
    const ts2 = event['ts2'];
    const query = await dynamo.send(
      new ScanCommand({ 
        TableName: tableName,
        FilterExpression: "ts BETWEEN :ts1 AND :ts2",
        ExpressionAttributeValues: {
            ":ts1": ts1,
            ":ts2": ts2,
        }
      })
    );
    const response = {
        statusCode: 200,
        body: JSON.stringify(query.Items),
    };
    return response;
    // https.get('http://ip.jsontest.com/', (resp) => {
    //     let data = '';
    //     // A chunk of data has been received.
    //     resp.on('data', (chunk) => {
    //       data += chunk;
    //     });
    //     // The whole response has been received. Print out the result.
    //     resp.on('end', () => {
    //       console.log(JSON.parse(data).explanation);
    //       const response = {
    //         statusCode: 200,
    //         body: JSON.stringify(data),
    //     };
    //     return response;
    //     });
    //         // console.log(query[0]);
    //       // TODO implement
    //     const response = {
    //         statusCode: 200,
    //         body: JSON.stringify(query.Items[0]),
    //     };
    //     return response;
    
    // }).on("error", (err) => {
    //   console.log("Error: " + err.message);
    //   const response = {
    //       statusCode: 500,
    //       body: JSON.stringify(err),
    //   };
    //     return response;
    // });



};


